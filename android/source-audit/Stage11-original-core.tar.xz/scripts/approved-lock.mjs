import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

export const fingerprint = b => crypto.createHash('sha256').update(b).digest('hex');
export function validateApproval(approval, snapshot, {strict=true} = {}) {
  if (!approval || approval.schema !== 1) throw Error('Missing or unsupported approved-assets.lock.json');
  if (approval.sourceDeployment !== snapshot.sourceDeployment) throw Error('Approved deployment differs from source-of-truth');
  if (approval.sourceUrl !== snapshot.sourceUrl) throw Error('Source URL differs from approved snapshot');
  if (!Array.isArray(approval.assets) || approval.assets.length === 0) throw Error('Approved assets missing');
  const stored = new Map(approval.assets.map(x=>[x.path,x]));
  if(stored.size !== approval.assets.length) throw Error('Duplicated approval asset paths');
  const actual = snapshot.assets || [];
  if (strict && stored.size !== actual.length) throw Error('Approved asset count mismatch');
  for (const a of actual) {
    const b=stored.get(a.path);
    if (!b || b.sha256 !== a.sha256 || b.bytes !== a.bytes) throw Error('Snapshot integrity mismatch: '+a.path);
  }
  return true;
}
export function readApproval(root) {
  const f=path.join(root,'approved-assets.lock.json');
  return fs.existsSync(f) ? JSON.parse(fs.readFileSync(f,'utf8')) : null;
}
