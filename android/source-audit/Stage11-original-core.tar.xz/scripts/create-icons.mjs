import fs from 'node:fs/promises';
import path from 'node:path';
import sharp from 'sharp';
const root=path.resolve(import.meta.dirname,'..');
const input=path.join(root,'www','bd-512.png');
await fs.mkdir(path.join(root,'assets'),{recursive:true});
const image=sharp(input);
await image.resize(1024,1024,{fit:'contain',background:'#071521'}).png().toFile(path.join(root,'assets','icon.png'));
console.log('Native icon generated from the APPROVED MainTrack web icon.');
