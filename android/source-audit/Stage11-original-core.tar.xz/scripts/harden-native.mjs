import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..');
const manifest=path.join(root,'android','app','src','main','AndroidManifest.xml');
if(!fs.existsSync(manifest))throw Error('AndroidManifest.xml missing; run android:prepare first');
let xml=fs.readFileSync(manifest,'utf8');
const attr=(s,name,value)=>{
  const pattern=new RegExp('\\bandroid:'+name+'="[^"]*"');
  return pattern.test(s)?s.replace(pattern,`android:${name}="${value}"`):s.replace(/<application\b/,`<application android:${name}="${value}"`);
};
if(!/<application\b/.test(xml))throw Error('Unexpected AndroidManifest.xml structure');
xml=attr(xml,'allowBackup','false');
xml=attr(xml,'usesCleartextTraffic','false');
xml=attr(xml,'networkSecurityConfig','@xml/maintrack_network_security');
fs.writeFileSync(manifest,xml);
const dir=path.join(root,'android','app','src','main','res','xml');fs.mkdirSync(dir,{recursive:true});
fs.writeFileSync(path.join(dir,'maintrack_network_security.xml'),`<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
  <base-config cleartextTrafficPermitted="false">
    <trust-anchors><certificates src="system" /></trust-anchors>
  </base-config>
</network-security-config>
`);
console.log('PASS: native backup disabled; cleartext HTTP disabled; system-trusted HTTPS only; no certificate pinning.');
