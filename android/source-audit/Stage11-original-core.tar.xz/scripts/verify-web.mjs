import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {validateApproval,readApproval} from './approved-lock.mjs';
const root=path.resolve(import.meta.dirname,'..');
const conf=JSON.parse(fs.readFileSync(path.join(root,'capacitor.config.json'),'utf8'));
if(conf.server?.url)throw Error('Remote server.url is forbidden for the release APK');
if(conf.server?.androidScheme!=='https'||conf.server.hostname!=='localhost')throw Error('Unexpected Android WebView origin');
const report=JSON.parse(fs.readFileSync(path.join(root,'www/security-build-report.json'),'utf8'));
if(report.strictScriptCSP!==true || report.issues?.length)throw Error('Security bundle guard failed');
const html=fs.readFileSync(path.join(root,'www/index.html'),'utf8');
if(!/http-equiv=["']Content-Security-Policy["']/.test(html)||!html.includes("script-src 'self'"))throw Error('Missing secure native CSP');
if(/<script\s*(?![^>]*\bsrc=)[^>]*>[\s\S]+?<\/script>/i.test(html))throw Error('Unexpected inline JS');
const api=fs.readFileSync(path.join(root,'www/secure-assets/index-inline-1.js'),'utf8');
if(!api.includes('maintrack-stage9-security-api/api') || api.includes('maintrack-stage6-api/api'))throw Error('Incorrect auth API');
const lock=JSON.parse(fs.readFileSync(path.join(root,'snapshot.lock.json'),'utf8'));
if(!Array.isArray(lock.assets)||lock.assets.length<10)throw Error('Missing web assets');
for(const item of lock.assets){
  if(!/^[\w.\/-]+$/.test(item.path)||item.path.includes('..'))throw Error('Unsafe path in asset lock');
  const f=path.join(root,'www',item.path);
  if(!fs.existsSync(f))throw Error('Snapshot asset missing: '+item.path);
  const body=fs.readFileSync(f);
  const digest=crypto.createHash('sha256').update(body).digest('hex');
  // index.html is deliberately modified after download to inject the native CSP.
  const expected=lock.nativeTransforms?.[item.path]||item;
  if(digest!==expected.sha256 || body.length!==expected.bytes)throw Error('Web asset integrity failed: '+item.path);
}
const approved=readApproval(root);if(approved)validateApproval(approved,lock);
if(process.env.MT_RELEASE==='1'&&!approved)throw Error('Missing reviewed approved-assets.lock.json');
console.log(`PASS — staged API / local assets / CSP / ${lock.assets.length} SHA256-checked web resources / ${approved?'approved':'review-candidate'} snapshot.`);
