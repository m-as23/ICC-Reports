import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import process from 'node:process';
import {validateApproval,readApproval} from './approved-lock.mjs';

const root = path.resolve(import.meta.dirname, '..');
const source = JSON.parse(await fs.readFile(path.join(root, 'source-of-truth.json'),'utf8'));
const testing = process.env.NODE_ENV === 'test' && process.env.MT_TEST_SOURCE_BASE;
const base = testing ? process.env.MT_TEST_SOURCE_BASE : source.approvedFrontend;
if (!testing && base !== 'https://maintrack-final-security-qa.vercel.app') {
  throw Error('Refusing a different, unreviewed MainTrack source origin.');
}
const baseUrl = new URL(base);
const target = path.join(root, 'www');
const temp = path.join(root, '.snapshot-temp');
await fs.rm(temp, {recursive:true,force:true});
await fs.mkdir(temp, {recursive:true});
const downloaded=[];
const fingerprint=b=>crypto.createHash('sha256').update(b).digest('hex');

async function download(relative){
  if(!/^[A-Za-z0-9][A-Za-z0-9_/.\-]*$/.test(relative) || relative.includes('..')) throw Error('Unsafe asset path: '+relative);
  const link=new URL(relative,baseUrl.href.endsWith('/')?baseUrl.href:baseUrl.href+'/');
  if(link.origin!==baseUrl.origin)throw Error('External download blocked: '+link.href);
  const timeout=AbortSignal.timeout(25000);
  const res=await fetch(link,{signal:timeout,redirect:'follow',headers:{'accept':'*/*','cache-control':'no-cache'}});
  if(!res.ok||new URL(res.url).origin!==baseUrl.origin)throw Error('Source unavailable or redirected to different origin: '+relative+' ('+res.status+')');
  const content=Buffer.from(await res.arrayBuffer());
  if(content.length===0 || content.length>4_000_000)throw Error('Unexpected asset size: '+relative);
  const dst=path.join(temp,relative);
  await fs.mkdir(path.dirname(dst),{recursive:true});await fs.writeFile(dst,content);
  downloaded.push({path:relative,sha256:fingerprint(content),bytes:content.length});
  return content;
}
function stopIfInvalidReport(report){
  if(report.strictScriptCSP!==true || report.apiEndpoint!=='stage9-isolated' || report.rewrittenApiReferences<1 || (report.issues||[]).length) {
    throw Error('Security report mismatch. Refusing to package an unapproved candidate.');
  }
  for(const [name,details] of Object.entries(report.pages||{})){
    if(details.remainingInlineScripts || details.inlineEventHandlers || details.javascriptURLs || details.remainingInlineStyles){
      throw Error('Unresolved inline executable content in '+name);
    }
  }
}

try{
  const buildReport=JSON.parse((await download('security-build-report.json')).toString('utf8'));
  stopIfInvalidReport(buildReport);
  const pages=['index.html','qa-security.html','security-final-check.html'].filter(x=>x in buildReport.pages);
  if(!pages.includes('index.html'))throw Error('No MainTrack app entry point in security build report');
  const core=['v6.js','v6-core.js','v6.css','v6-core.css','manifest.webmanifest','bd-192.png','bd-512.png'];
  const more=new Set([...pages,...core]);
  for(const d of Object.values(buildReport.pages)){
    for(const s of d.externalScriptSrcs||[]) {
      if(s.startsWith('http') || s.startsWith('//'))continue;
      more.add(s);
    }
  }
  // All CSS extracted from each page by the approved Stage9 production build.
  for(const pg of pages){
    const name=pg.replace(/\.html$/,'');
    const d=buildReport.pages[pg];
    for(let i=1;i<=d.stylesExternalized;i++)more.add(`secure-assets/${name}-inline-${i}.css`);
  }
  for(const name of more)await download(name);
  const entry=path.join(temp,'index.html');
  let html=await fs.readFile(entry,'utf8');
  const securityCsp=[
    "default-src 'self'", "script-src 'self'", "script-src-attr 'none'",
    "style-src 'self' https://fonts.googleapis.com", "style-src-attr 'unsafe-inline'",
    "font-src 'self' https://fonts.gstatic.com data:",
    "img-src 'self' data: blob: https:",
    `connect-src 'self' ${source.backendOrigin}`,
    "worker-src 'self' blob:", "media-src 'self' blob: data:",
    "base-uri 'none'", "object-src 'none'", "form-action 'self'", "upgrade-insecure-requests"
  ].join('; ');
  const meta=`<meta http-equiv="Content-Security-Policy" content="${securityCsp}">`;
  if(!/<head[^>]*>/i.test(html))throw Error('Missing head tag; Capacitor injection would fail');
  html=html.replace(/<meta\s+http-equiv=["']Content-Security-Policy["'][^>]*>/gi,'');
  html=html.replace(/(<head[^>]*>)/i,`$1\n${meta}`);
  if(html.includes('maintrack-stage6-api/api'))throw Error('Unexpected legacy API in app HTML');
  await fs.writeFile(entry,html,'utf8');
  const mainJs=path.join(temp,'secure-assets/index-inline-1.js');
  const js=await fs.readFile(mainJs,'utf8');
  if(!js.includes('/functions/v1/maintrack-stage9-security-api/api'))throw Error('MainTrack did not target the isolated Stage9 API');
  if(js.includes('/functions/v1/maintrack-stage6-api/api'))throw Error('Old backend API still referenced');
  const packagedIndex=Buffer.from(html,'utf8');
  const manifest={sourceUrl:base,sourceDeployment:source.sourceDeploymentId,createdAt:new Date().toISOString(),appOrigin:source.androidOrigin,backendOrigin:source.backendOrigin,assets:downloaded,nativeTransforms:{'index.html':{sha256:fingerprint(packagedIndex),bytes:packagedIndex.length}}};
  const approval=readApproval(root);
  if (approval) validateApproval(approval,manifest);
  if (!approval && process.env.MT_RELEASE==='1') throw Error('Refusing release without reviewed approved-assets.lock.json');
  // Important: validate all downloaded assets before overwriting the previous, known-good www snapshot.
  await fs.rm(target,{recursive:true,force:true}); await fs.rename(temp,target);
  await fs.writeFile(path.join(root,'snapshot.lock.json'),JSON.stringify(manifest,null,2));
  console.log(`MainTrack secure snapshot ready: ${downloaded.length} files; ${downloaded.reduce((sum,x)=>sum+x.bytes,0)} bytes; approved=${!!approval}; no server.url; CSP meta injected.`);
}catch(error){await fs.rm(temp,{recursive:true,force:true}); console.error(error);process.exitCode=1;}
