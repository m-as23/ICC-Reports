import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const root=path.resolve(import.meta.dirname,'..');
if(!fs.existsSync(path.join(root,'www','index.html')))throw Error('Run npm run build:web first');
const bin=process.platform==='win32'?'npx.cmd':'npx';
const native=path.join(root,'android','app','build.gradle');
const cmd=fs.existsSync(native)?['cap','sync','android']:['cap','add','android'];
function run(args){console.log('>',bin,...args);const r=spawnSync(bin,args,{cwd:root,stdio:'inherit'});if(r.status!==0)process.exit(r.status||1)}
run(cmd);
if(cmd[1]==='add')run(['cap','sync','android']);

const harden=spawnSync(process.execPath,['scripts/harden-native.mjs'],{cwd:root,stdio:'inherit'});
if(harden.status!==0)process.exit(harden.status||1);
