import fs from 'node:fs';
import path from 'node:path';
import {validateApproval,readApproval} from './approved-lock.mjs';
const root=path.resolve(import.meta.dirname,'..');
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const lockPath=path.join(root,'package-lock.json');
if(!fs.existsSync(lockPath))throw Error('Release blocked: package-lock.json missing. Generate, review and commit dependency lockfile.');
const lock=JSON.parse(fs.readFileSync(lockPath,'utf8'));
if(lock.lockfileVersion<3 || lock.name!==pkg.name || lock.version!==pkg.version) throw Error('Release blocked: package-lock header mismatch');
for(const [k,v] of Object.entries({...pkg.dependencies,...pkg.devDependencies})){
  if(lock.packages?.['']?.dependencies?.[k]!==undefined){if(lock.packages[''].dependencies[k]!==v)throw Error('Package lock mismatch: '+k)}
  else if(lock.packages?.['']?.devDependencies?.[k]!==v)throw Error('Package lock mismatch: '+k);
  if(!lock.packages?.['node_modules/'+k]?.version)throw Error('Dependency unresolved in lockfile: '+k);
}
const approval=readApproval(root);
if(!approval)throw Error('Release blocked: approved-assets.lock.json missing');
const snapshot=JSON.parse(fs.readFileSync(path.join(root,'snapshot.lock.json'),'utf8'));
validateApproval(approval,snapshot);
const config=JSON.parse(fs.readFileSync(path.join(root,'capacitor.config.json'),'utf8'));
if(config.server?.url || config.server?.hostname!=='localhost' || config.server?.androidScheme!=='https') throw Error('Release blocked: Android WebView source changed');
console.log('PASS: signed release gates: dependency lock, exact approved web resources, native origin.');
