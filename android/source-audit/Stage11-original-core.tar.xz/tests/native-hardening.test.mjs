import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
test('Android manifest hardened idempotently and Android version can be explicitly increased',async()=>{
 const p=await fs.mkdtemp(path.join(os.tmpdir(),'mt-native-hardening-'));
 try{
  await fs.mkdir(path.join(p,'scripts'),{recursive:true});
  await fs.mkdir(path.join(p,'android/app/src/main'),{recursive:true});
  await fs.mkdir(path.join(p,'android/app'),{recursive:true});
  await fs.copyFile(path.join(project,'scripts/harden-native.mjs'),path.join(p,'scripts/harden-native.mjs'));
  await fs.copyFile(path.join(project,'scripts/bump-native-version.mjs'),path.join(p,'scripts/bump-native-version.mjs'));
  const manifest=path.join(p,'android/app/src/main/AndroidManifest.xml');
  await fs.writeFile(manifest,'<?xml version="1.0"?><manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:label="MainTrack" android:allowBackup="true"><activity android:name=".MainActivity" /></application></manifest>');
  const cmd=(name,env={})=>spawnSync(process.execPath,['scripts/'+name+'.mjs'],{cwd:p,env:{...process.env,...env},encoding:'utf8'});
  assert.equal(cmd('harden-native').status,0);
  assert.equal(cmd('harden-native').status,0);
  const xml=await fs.readFile(manifest,'utf8');
  assert.equal((xml.match(/android:allowBackup=/g)||[]).length,1);
  assert.match(xml,/android:allowBackup="false"/);
  assert.match(xml,/android:usesCleartextTraffic="false"/);
  assert.match(xml,/android:networkSecurityConfig="@xml\/maintrack_network_security"/);
  const net=await fs.readFile(path.join(p,'android/app/src/main/res/xml/maintrack_network_security.xml'),'utf8');
  assert.match(net,/cleartextTrafficPermitted="false"/);
  const gradle=path.join(p,'android/app/build.gradle');
  await fs.writeFile(gradle,'android { defaultConfig { versionCode 1; versionName "1.0" } }');
  assert.notEqual(cmd('bump-native-version',{MT_ANDROID_VERSION_CODE:'abc',MT_ANDROID_VERSION_NAME:'0.2.0'}).status,0);
  const ok=cmd('bump-native-version',{MT_ANDROID_VERSION_CODE:'12',MT_ANDROID_VERSION_NAME:'0.2.0'});
  assert.equal(ok.status,0,ok.stderr);
  const updated=await fs.readFile(gradle,'utf8');
  assert.match(updated,/versionCode 12/);
  assert.match(updated,/versionName "0.2.0"/);
 }finally{await fs.rm(p,{recursive:true,force:true});}
});
