import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {validateApproval} from '../scripts/approved-lock.mjs';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
function run(args,cwd,env={}){
 return new Promise((resolve,reject)=>{
  const p=spawn(process.execPath,args,{cwd,env:{...process.env,...env},stdio:['ignore','pipe','pipe']});let output='';
  p.stdout.on('data',b=>output+=b);p.stderr.on('data',b=>output+=b);
  p.once('error',reject);p.once('close',status=>resolve({status,output}));
 });
}

test('asset approval cannot accept a changed digest, count or deployment',()=>{
 const snapshot={sourceUrl:'https://example.test',sourceDeployment:'dpl_1',assets:[{path:'app.js',sha256:'a'.repeat(64),bytes:2}]};
 const approval={schema:1,sourceUrl:snapshot.sourceUrl,sourceDeployment:snapshot.sourceDeployment,assets:[...snapshot.assets]};
 assert.equal(validateApproval(approval,snapshot),true);
 assert.throws(()=>validateApproval({...approval,sourceDeployment:'dpl_2'},snapshot),/deployment/);
 assert.throws(()=>validateApproval({...approval,assets:[{...approval.assets[0],sha256:'b'.repeat(64)}]},snapshot),/integrity/);
 assert.throws(()=>validateApproval({...approval,assets:[]},snapshot),/missing/);
});

test('offline mock snapshot: SHA-256 manifest, approved lock, tamper rejection and no web overwrite',async()=>{
 const temp=await fs.mkdtemp(path.join(os.tmpdir(),'mt-stage11-test-'));
 const entries=new Map();
 let server;
 try{
  await fs.mkdir(path.join(temp,'scripts'),{recursive:true});
  for(const file of ['snapshot-approved.mjs','verify-web.mjs','approved-lock.mjs']){
   await fs.copyFile(path.join(root,'scripts',file),path.join(temp,'scripts',file));
  }
  await fs.copyFile(path.join(root,'capacitor.config.json'),path.join(temp,'capacitor.config.json'));
  await fs.copyFile(path.join(root,'source-of-truth.json'),path.join(temp,'source-of-truth.json'));
  const html='<html><head><meta charset="utf-8"></head><body><script src="secure-assets/index-inline-1.js"></script></body></html>';
  const report={strictScriptCSP:true,apiEndpoint:'stage9-isolated',rewrittenApiReferences:1,issues:[],pages:{
   'index.html':{remainingInlineScripts:0,inlineEventHandlers:0,javascriptURLs:0,remainingInlineStyles:0,stylesExternalized:1,externalScriptSrcs:['secure-assets/index-inline-1.js']},
   'qa-security.html':{remainingInlineScripts:0,inlineEventHandlers:0,javascriptURLs:0,remainingInlineStyles:0,stylesExternalized:0,externalScriptSrcs:[]},
   'security-final-check.html':{remainingInlineScripts:0,inlineEventHandlers:0,javascriptURLs:0,remainingInlineStyles:0,stylesExternalized:0,externalScriptSrcs:[]}
  }};
  entries.set('security-build-report.json',JSON.stringify(report));
  for(const page of Object.keys(report.pages))entries.set(page,html);
  for(const name of ['v6.js','v6-core.js','v6.css','v6-core.css'])entries.set(name,'/* fixture */');
  entries.set('manifest.webmanifest','{"name":"MainTrack"}');
  entries.set('bd-192.png',Buffer.from([137,80,78,71,10]));
  entries.set('bd-512.png',Buffer.from([137,80,78,71,11]));
  entries.set('secure-assets/index-inline-1.css','body{font-size:14px}');
  entries.set('secure-assets/index-inline-1.js',"const API='https://tdnkeskczcsukcujwinu.supabase.co/functions/v1/maintrack-stage9-security-api/api';");
  server=http.createServer((req,res)=>{const key=decodeURIComponent((req.url||'').slice(1));if(!entries.has(key)){res.writeHead(404).end();return;}res.writeHead(200,{'content-type':'application/octet-stream'}).end(entries.get(key));});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const env={NODE_ENV:'test',MT_TEST_SOURCE_BASE:`http://127.0.0.1:${server.address().port}`};
  const initial=await run(['scripts/snapshot-approved.mjs'],temp,env);
  assert.equal(initial.status,0,initial.output);
  const verified=await run(['scripts/verify-web.mjs'],temp,env);
  assert.equal(verified.status,0,verified.output);
  const lock=JSON.parse(await fs.readFile(path.join(temp,'snapshot.lock.json'),'utf8'));
  assert.ok(lock.assets.length>=10);
  const approval={schema:1,sourceUrl:lock.sourceUrl,sourceDeployment:lock.sourceDeployment,assets:lock.assets};
  await fs.writeFile(path.join(temp,'approved-assets.lock.json'),JSON.stringify(approval));
  const again=await run(['scripts/snapshot-approved.mjs'],temp,env);
  assert.equal(again.status,0,again.output);
  // After approval, even a small upstream edit must not replace the known-good www bytes.
  const before=await fs.readFile(path.join(temp,'www','v6.js'));
  entries.set('v6.js','/* malicious upstream change to previously approved source */');
  const changed=await run(['scripts/snapshot-approved.mjs'],temp,env);
  assert.notEqual(changed.status,0,changed.output);
  assert.match(changed.output,/integrity mismatch/);
  assert.deepEqual(await fs.readFile(path.join(temp,'www','v6.js')),before);
  // Local tampering detection.
  await fs.writeFile(path.join(temp,'www','v6.js'),'tampered');
  const corrupt=await run(['scripts/verify-web.mjs'],temp,env);
  assert.notEqual(corrupt.status,0,corrupt.output);
  assert.match(corrupt.output,/integrity failed/);
 }finally{
  if(server)await new Promise(resolve=>server.close(resolve));
  await fs.rm(temp,{recursive:true,force:true});
 }
});
