package com.icc.maintrack.qa;
import com.getcapacitor.*;
import android.webkit.*;
import android.net.http.SslError;
import android.net.Uri;
import java.io.ByteArrayInputStream;
public class QaWebViewClient extends BridgeWebViewClient {
 public QaWebViewClient(Bridge bridge){super(bridge);}
 private boolean local(Uri u){return "https".equals(u.getScheme())&&"localhost".equals(u.getHost())&&u.getUserInfo()==null&&(u.getPort()==-1||u.getPort()==443);}
 @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){
  if(!local(request.getUrl()))return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));
  return super.shouldInterceptRequest(view,request);
 }
 @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return !local(request.getUrl());}
 @Override public void onReceivedSslError(WebView view,SslErrorHandler handler,SslError error){handler.cancel();}
}
