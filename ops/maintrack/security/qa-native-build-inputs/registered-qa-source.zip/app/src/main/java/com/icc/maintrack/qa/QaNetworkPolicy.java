package com.icc.maintrack.qa;
import java.net.URI;
import java.util.Arrays;
public final class QaNetworkPolicy {
 public static final String HOST="szhstrafzkxzstjdcynl.supabase.co";
 public static final String CORE="/functions/v1/maintrack-security-qa-final/api";
 public static final String INVENTORY="/functions/v1/maintrack-security-qa-inventory";
 public static boolean allowed(String value,String method,String action){
  try{
   URI u=new URI(value);
   if(!"https".equals(u.getScheme())||!HOST.equals(u.getHost())||u.getUserInfo()!=null||u.getRawQuery()!=null||u.getRawFragment()!=null||(u.getPort()!=-1&&u.getPort()!=443)||value.contains("%")||value.contains("\\")||!u.normalize().equals(u))return false;
   String p=u.getRawPath();
   if("GET".equals(method))return p.equals("/functions/v1/maintrack-security-qa-final/readyz")||p.equals("/functions/v1/maintrack-security-qa-inventory/readyz");
   if(!"POST".equals(method))return false;
   if(CORE.equals(p))return Arrays.asList("login","change","session","init","nextId","profile","dashboard","notifications","accountSummary","leaveMine","overtimeMine","adminUsers","teamBalances","teamBalanceDetail").contains(action);
   return INVENTORY.equals(p)&&Arrays.asList("inventorySearchCapabilities","inventorySnapshot","inventoryVersion","inventorySearch","inventorySearchPage","inventoryItem","inventoryVersions","inventoryHistory","inventoryActivity").contains(action);
  }catch(Exception e){return false;}
 }
}
