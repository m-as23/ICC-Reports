package com.icc.maintrack.qa;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import javax.net.ssl.HttpsURLConnection;
import java.net.URL;
@CapacitorPlugin(name="QaTlsProbe")
public class QaTlsProbePlugin extends Plugin {
 @PluginMethod public void probe(PluginCall call){
  String fixture=call.getString("fixture","");int port;
  if(fixture.equals("trusted"))port=8443;else if(fixture.equals("wrong-host"))port=8444;else if(fixture.equals("untrusted"))port=8445;else {call.reject("QA_TLS_FIXTURE_DENIED");return;}
  final int p=port;
  new Thread(()->{HttpsURLConnection c=null;JSObject r=new JSObject();try{c=(HttpsURLConnection)new URL("https://10.0.2.2:"+p+"/tls").openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(5000);c.setReadTimeout(5000);r.put("accepted",c.getResponseCode()==200);r.put("cipher",c.getCipherSuite());}catch(Exception e){r.put("accepted",false);r.put("errorType",e.getClass().getSimpleName());}finally{if(c!=null)c.disconnect();}call.resolve(r);},"maintrack-qa-tls").start();
 }
}
