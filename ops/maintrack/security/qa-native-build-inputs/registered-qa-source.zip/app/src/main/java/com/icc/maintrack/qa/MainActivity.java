package com.icc.maintrack.qa;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
@Override public void onCreate(android.os.Bundle state) {
 registerPlugin(MainTrackSecureSessionPlugin.class);
 registerPlugin(MainTrackQaTransportPlugin.class);
 registerPlugin(QaDisabledHttpPlugin.class);
 registerPlugin(QaUpdaterPlugin.class);
 registerPlugin(QaTlsProbePlugin.class);
 registerPlugin(MainTrackPasskeyPlugin.class);
 super.onCreate(state);
 getBridge().getWebView().setWebViewClient(new MainTrackQaWebViewClient(getBridge()));
 getBridge().getWebView().getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
 android.webkit.ServiceWorkerController.getInstance().getServiceWorkerWebSettings().setBlockNetworkLoads(true);
}}
