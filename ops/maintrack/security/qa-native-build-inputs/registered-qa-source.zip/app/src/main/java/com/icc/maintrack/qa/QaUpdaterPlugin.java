package com.icc.maintrack.qa;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import ee.forgr.capacitor_updater.CapacitorUpdaterPlugin;
@CapacitorPlugin(name="CapacitorUpdater")
public class QaUpdaterPlugin extends CapacitorUpdaterPlugin {
 @Override @PluginMethod public void download(PluginCall call){
  String url=call.getString("url","");
  if(!url.matches("https://10\\.0\\.2\\.2:8443/(good|bad|tampered)\\.zip")||!call.getString("checksum","").matches("[a-f0-9]{64}")||call.getData().has("manifest")||!call.getString("sessionKey","").isEmpty()){call.reject("QA_OTA_DESTINATION_DENIED");return;}
  super.download(call);
 }
 @Override @PluginMethod public void setUpdateUrl(PluginCall call){call.reject("QA_URL_IMMUTABLE");}
 @Override @PluginMethod public void setStatsUrl(PluginCall call){call.reject("QA_URL_IMMUTABLE");}
 @Override @PluginMethod public void setChannelUrl(PluginCall call){call.reject("QA_URL_IMMUTABLE");}
}
