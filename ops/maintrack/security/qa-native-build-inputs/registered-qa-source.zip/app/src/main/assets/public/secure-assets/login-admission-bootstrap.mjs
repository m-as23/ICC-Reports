import {installRegisteredNativeClient} from './registered-login-native-client.mjs';
import {installLoginProofClient} from './login-turnstile-client.mjs';
// Missing public config blocks Login locally before any gateway or provider request.
const response=await fetch('./login-admission-public.json',{cache:'no-store'});const config=await response.json();
if(config.enabled!==true||!config.sitekey||!config.gatewayUrl||!config.gatewayHost)throw Error('QA_LOGIN_ADMISSION_PUBLIC_CONFIG_REQUIRED');
const gatewayOrigin=new URL(config.gatewayUrl).origin;
const csp=document.querySelector('meta[http-equiv="Content-Security-Policy"]')?.content||'';
const connection=csp.split(';').find(x=>x.trim().startsWith('connect-src '))||'';
if(!(connection.split(/\s+/).includes(gatewayOrigin)||(connection.includes("'self'")&&location.origin===gatewayOrigin)))throw Error('QA_GATEWAY_CSP_REBUILD_REQUIRED');

const button=document.getElementById('lgo');if(!button)throw Error('QA_LOGIN_MOUNT_REQUIRED');
const element=document.createElement('div');element.id='maintrack-login-proof';button.before(element);
await new Promise((resolve,reject)=>{const script=document.createElement('script');script.src='https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';script.async=true;const timer=setTimeout(()=>{script.remove();reject(Error('LOGIN_PROVIDER_UNAVAILABLE'));},15000);script.onload=()=>{clearTimeout(timer);resolve();};script.onerror=()=>{clearTimeout(timer);script.remove();reject(Error('LOGIN_PROVIDER_UNAVAILABLE'));};document.head.append(script);});
installLoginProofClient({scope:window,widget:window.turnstile,element,sitekey:config.sitekey,gatewayUrl:config.gatewayUrl,allowedGatewayHost:config.gatewayHost});

if(!window.Capacitor?.PluginHeaders?.some(p=>p.name==='MainTrackPasskey'))throw Error('NATIVE_PASSKEY_BUILD_REQUIRED');
const nativeBridge={create:request=>Capacitor.nativePromise('MainTrackPasskey','create',request),get:request=>Capacitor.nativePromise('MainTrackPasskey','get',request)};
installRegisteredNativeClient({scope:window,bridge:nativeBridge,endpoint:config.gatewayUrl,allowedGatewayHost:config.gatewayHost,enabled:config.registeredIdentity?.enabled===true});
