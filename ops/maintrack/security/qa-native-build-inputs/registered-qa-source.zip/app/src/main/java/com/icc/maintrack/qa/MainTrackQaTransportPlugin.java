package com.icc.maintrack.qa;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import javax.net.ssl.HttpsURLConnection;
import java.net.URL;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import org.json.*;

@CapacitorPlugin(name="MainTrackQaTransport")
public class MainTrackQaTransportPlugin extends Plugin {
 private volatile String capability="";
 private long lastRequest=0;
 private int count=0,blocked=0;
 private final JSONArray audit=new JSONArray();
 private final ExecutorService queue=Executors.newSingleThreadExecutor();
 @PluginMethod public void configure(PluginCall call){
  String value=call.getString("capability","");
  if(!value.matches("[a-f0-9]{64}")){call.reject("QA_CAPABILITY_INVALID");return;}
  capability=value;JSObject out=new JSObject();out.put("configured",true);call.resolve(out);
 }
 @PluginMethod public void clear(PluginCall call){capability="";call.resolve();}
 @PluginMethod public void status(PluginCall call){synchronized(audit){JSObject out=new JSObject();out.put("configured",!capability.isEmpty());out.put("count",count);out.put("blocked",blocked);out.put("requests",audit);call.resolve(out);}}
 @PluginMethod public void request(PluginCall call){
  final String url=call.getString("url",""),method=call.getString("method","POST"),body=call.getString("body","{}");
  String parsedAction="";
  try{if(body.getBytes(StandardCharsets.UTF_8).length>65536)throw new Exception();parsedAction=new JSONObject(body).optString("action","");}catch(Exception e){call.reject("QA_PAYLOAD_DENIED");return;}
  final String action=parsedAction;
  if(!QaNetworkPolicy.allowed(url,method,action)){blocked++;call.reject("QA_DESTINATION_OR_ACTION_DENIED");return;}
  if(capability.isEmpty()){call.reject("QA_CHANNEL_LOCKED");return;}
  final String authorization=call.getString("authorization","");
  if(!authorization.isEmpty()&&!authorization.matches("Bearer [a-f0-9]{64}")){call.reject("QA_AUTH_HEADER_DENIED");return;}
  queue.execute(()->{
   HttpsURLConnection connection=null;
   try{
    if(capability.isEmpty()||count>=55){call.reject("QA_LOCAL_BUDGET_OR_CHANNEL_CLOSED");return;}
    long delay=2500-(System.currentTimeMillis()-lastRequest);if(delay>0)Thread.sleep(delay);
    lastRequest=System.currentTimeMillis();count++;
    connection=(HttpsURLConnection)new URL(url).openConnection();
    connection.setConnectTimeout(12000);connection.setReadTimeout(18000);connection.setInstanceFollowRedirects(false);
    connection.setRequestMethod(method);connection.setRequestProperty("Content-Type","application/json");connection.setRequestProperty("Origin","https://localhost");
    connection.setRequestProperty("x-maintrack-qa-run-id","SECURITY_FINAL_20261025");connection.setRequestProperty("x-maintrack-qa-capability",capability);
    if(!authorization.isEmpty())connection.setRequestProperty("Authorization",authorization);
    if("POST".equals(method)){connection.setDoOutput(true);try(OutputStream out=connection.getOutputStream()){out.write(body.getBytes(StandardCharsets.UTF_8));}}
    int status=connection.getResponseCode();
    if(status>=300&&status<400)throw new IOException("QA_REDIRECT_DENIED");
    InputStream input=status>=400?connection.getErrorStream():connection.getInputStream();ByteArrayOutputStream bytes=new ByteArrayOutputStream();
    if(input!=null)try(InputStream in=input){byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1){if(bytes.size()+n>2097152)throw new IOException("QA_RESPONSE_LIMIT");bytes.write(buffer,0,n);}}
    JSObject out=new JSObject();out.put("status",status);out.put("body",bytes.toString("UTF-8"));
    synchronized(audit){JSONObject row=new JSONObject();row.put("path",new URL(url).getPath());row.put("action",action);row.put("status",status);audit.put(row);}
    call.resolve(out);
   }catch(Exception e){synchronized(audit){JSONObject row=new JSONObject();try{row.put("action",action);row.put("status","NETWORK_ERROR");row.put("errorType",e.getClass().getSimpleName());audit.put(row);}catch(Exception ignored){}}call.reject("QA_NETWORK_ERROR");}
   finally{lastRequest=System.currentTimeMillis();if(connection!=null)connection.disconnect();}
  });
 }
}
