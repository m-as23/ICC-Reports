package com.icc.maintrack.qa;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
@CapacitorPlugin(name="CapacitorHttp")
public class QaDisabledHttpPlugin extends Plugin {
 @PluginMethod public void request(PluginCall call){call.reject("QA_UNAUDITED_HTTP_DISABLED");}
 @PluginMethod public void get(PluginCall call){call.reject("QA_UNAUDITED_HTTP_DISABLED");}
 @PluginMethod public void post(PluginCall call){call.reject("QA_UNAUDITED_HTTP_DISABLED");}
 @PluginMethod public void put(PluginCall call){call.reject("QA_UNAUDITED_HTTP_DISABLED");}
 @PluginMethod public void patch(PluginCall call){call.reject("QA_UNAUDITED_HTTP_DISABLED");}
 @PluginMethod public void delete(PluginCall call){call.reject("QA_UNAUDITED_HTTP_DISABLED");}
 @PluginMethod public void head(PluginCall call){call.reject("QA_UNAUDITED_HTTP_DISABLED");}
 @PluginMethod public void options(PluginCall call){call.reject("QA_UNAUDITED_HTTP_DISABLED");}
}
